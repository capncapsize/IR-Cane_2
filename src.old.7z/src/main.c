/**
*****************************************************************************
**
**  File        : main.c
**
**  Abstract    : main function.
**
**  Functions   : main
**
**  Environment : Atollic TrueSTUDIO(R)
**                STMicroelectronics STM32F4xx Standard Peripherals Library
**
**  Distribution: The file is distributed "as is", without any warranty
**                of any kind.
**
**  (c)Copyright Atollic AB.
**  You may use this file as-is or modify it according to the needs of your
**  project. This file may only be built (assembled or compiled and linked)
**  using the Atollic TrueSTUDIO(R) product. The use of this file together
**  with other tools than Atollic TrueSTUDIO(R) is not permitted.
**
*****************************************************************************
*/

/* Includes */
#include "stm32f4xx.h"
#include "stm32f4xx_usart.h"

#include "serial_com.h"
#include "clock_conf.h"
#include "timer_conf.h"

/* Private macro */
/* Private variables */
/* Private function prototypes */
/* Private functions */

/**
**===========================================================================
**
**  Abstract: main program
**
**===========================================================================
*/

int main(void)
{
  /*RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;

  GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_SetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_6);*/

  RCC->AHB1RSTR |= RCC_AHB1RSTR_GPIOARST;    // Reset GPIOA
  RCC->AHB1RSTR = 0;                         // Exit reset state
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;       // Enable GPIOA clock
  GPIOA->MODER |= GPIO_MODER_MODER5_0;	   // Enable Output on A5 (LED2 on Nucleo F401RE board)



  /* GPIOB clock enable */
  //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);


  //(*((volatile uint32_t *)0x40020014)) = (1<<5);

  init_clock();
  init_USART2();
  //init_TIM1();

  serial_send_data("System Ready\r");



  volatile i = 0;
  while (1){
	  serial_get_data();
	  i++;
  }
  return 0;
}

/*void usartSetup (void) {
  // make sure the relevant pins are appropriately set up.
  RCC_APB2ENR |= RCC_APB2ENR_IOPAEN;              // enable clock for GPIOA
  GPIOA_CRH   |= (0x0BUL  << 4);                  // Tx (PA9) alt. out push-pull
  GPIOA_CRH   |= (0x04UL  << 8);                  // Rx (PA10) in floating
  RCC_APB2ENR |= RCC_APB2ENR_USART1EN;            // enable clock for USART1
  USART1_BRR  = 64000000L/115200L;                // set baudrate
  USART1_CR1 |= (USART1_CR1_RE | USART1_CR1_TE);  // RX, TX enable
  USART1_CR1 |= USART1_CR1_UE;                    // USART enable
  }

int SendChar (int ch)  {
  while (!(USART1_SR & USART1_SR_TXE));
  USART1_DR = (ch & 0xFF);
  return (ch);
}

int GetChar (void)  {
  while (!(USART1_SR & USART1_SR_RXNE));
  return ((int)(USART1_DR & 0xFF));
}*/

/**************************************************************************************/

/*int main1(void)
{
  RCC_Configuration();

  GPIO_Configuration();

  USART2_Configuration();

  OutString("Welcome to Nucleo F401RE\r\n");

  while(1) // Don't want to exit
  {
    uint16_t Data;

    while(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET); // Wait for Char

    Data = USART_ReceiveData(USART2); // Collect Char

    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET); // Wait for Empty

    USART_SendData(USART2, Data); // Echo Char
  }
}*/

