/*
 * timer_conf.c
 *
 *  Created on: Feb 16, 2016
 *      Author: daveng-2
 */

#include "timer_conf.h"

uint16_t current_count = 0;


int init_TIM1(void){
	/* Init struct*/
	GPIO_InitTypeDef		GPIO_InitStructure;
	NVIC_InitTypeDef 		NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TBInitStructure;
	TIM_OCInitTypeDef 		TIM_OCInitStructure;

	/* Enable clock on peripherals */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	/* Enable TIM1-CH4 on PA11*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_TIM1);

	/* Enable compare interrupt on TIM1 */
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	/* Set clock time base */
	TIM_TBInitStructure.TIM_ClockDivision = 1;
	TIM_TBInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TBInitStructure.TIM_Period = 65535;
	TIM_TBInitStructure.TIM_Prescaler = TIM_PRESCALER;
	TIM_TimeBaseInit(TIM1, &TIM_TBInitStructure);

	/* Set clock OC*/
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Toggle;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
	TIM_OCInitStructure.TIM_Pulse = TIM1_PULSE;
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Disable);

	/* Disable OPM */
	TIM1->CR1 &= ~(1 << 4);

	//TIM1->CR2 &=

	TIM_Cmd(TIM1, ENABLE);
	TIM_ITConfig(TIM1, TIM_IT_CC1, ENABLE);

	return 1;
}

void TIM1_CC_IRQHandler(void)
{
  GPIOA->ODR ^= (1 << (5));
  if (TIM_GetITStatus(TIM1, TIM_IT_CC1) != RESET)             // Just a precaution (RESET = 0)
  {
    TIM_ClearITPendingBit(TIM1, TIM_IT_CC1);                  // Clear TIM1 Ch.1 flag
    current_count = TIM_GetCapture1(TIM1);                   // Get current counter value
    TIM_SetCompare1(TIM1, current_count + TIM1_PULSE);        // Set Output Compare 1 to the new value
  }
}
