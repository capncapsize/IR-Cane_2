/*
 * serial_com.c
 *
 *  Created on: Feb 9, 2016
 *      Author: daveng-2
 */

#include "serial_com.h"


static block dequeue(block *queue);
static void enqueue(block p, block *queue);
static void initialize(void);

#define NBLOCKS        25


struct data_block {
    char c;
    block next;
};

struct data_block blocks[NBLOCKS];

struct data_block initp;

block freeQ   = blocks;
block TxQ  = NULL;
block RxQ  = NULL;
block current = &initp;

int initialized = 0;
int RxQ_ready = 0;

char err[] = "Error: ";
char* on = "on\r";
char* off = "off\r";

int init_USART2(void){
	  /* Enable clock on peripherals */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	  GPIO_InitTypeDef  GPIO_InitStructure;
	  USART_InitTypeDef USART_InitStructure;

	  // Initialize pins as alternating function
	  GPIO_InitStructure.GPIO_Pin     = GPIO_Pin_2 | GPIO_Pin_3;
	  GPIO_InitStructure.GPIO_Mode    = GPIO_Mode_AF;
	  GPIO_InitStructure.GPIO_OType   = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_PuPd    = GPIO_PuPd_UP;
	  GPIO_InitStructure.GPIO_Speed   = GPIO_Speed_2MHz;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);

	  GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	  GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

	  // Modify USART_InitStructure for non -default values , e.g.
	  USART_InitStructure.USART_BaudRate              = 115200*3;
	  USART_InitStructure.USART_WordLength            = USART_WordLength_8b;
	  USART_InitStructure.USART_StopBits              = USART_StopBits_1;
	  USART_InitStructure.USART_Parity                = USART_Parity_No;
	  USART_InitStructure.USART_HardwareFlowControl   = USART_HardwareFlowControl_None;
	  USART_InitStructure.USART_Mode                  = USART_Mode_Tx|USART_Mode_Rx;
	  USART_Init(USART2 ,&USART_InitStructure);
	  USART_Cmd(USART2 , ENABLE);

	  USART2->CR1 |= USART_CR1_RXNEIE;	//RX interrupt
	  //USART2->CR1 |= USART_CR1_TXEIE;	//TX interrupt
	  //NVIC->ISER[1] |= (1 << (USART2_IRQChannel & 0x1F));

	  NVIC_InitTypeDef NVIC_InitStruct;
	  NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
	  NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	  NVIC_Init(&NVIC_InitStruct);


	return 0;
}

void USART2_IRQHandler(void){

	if(USART_GetITStatus(USART2, USART_IT_RXNE)){
		char c = (USART2->DR & (uint16_t)0x01FF);
		block ptr = dequeue(&freeQ);
		ptr->c = c;
		enqueue(ptr, &RxQ);
		if(c == '\r'){
			RxQ_ready = 1;
		}
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
	if(USART_GetITStatus(USART2, USART_IT_TXE)){
//		USART2->DR = (*TXpoint & (uint16_t)0x01FF);
//		TXpoint++;
//		if(*TXpoint == '\0'){
//			USART2->CR1 &= (~USART_FLAG_TXE);
//			TXpoint = &TXarray[0];
//		}

		block s = dequeue(&TxQ);
		if(s == NULL){
			USART2->CR1 &= (~USART_FLAG_TXE);
		}else{
			USART2->DR = (s->c & (uint16_t)0x01FF);
		}
		enqueue(s, &freeQ);
		USART_ClearITPendingBit(USART2, USART_IT_TXE);
	}
}

static void initialize(void) {
    int i;
    for (i=0; i<NBLOCKS-1; i++)
        blocks[i].next = &blocks[i+1];
    blocks[NBLOCKS-1].next = NULL;

    initialized = 1;
}

static void enqueue(block p, block *queue) {
    p->next = NULL;
    if (*queue == NULL) {
        *queue = p;
    } else {
        block q = *queue;
        while (q->next)
            q = q->next;
        q->next = p;
    }
}

static block dequeue(block *queue) {
    block p = *queue;
    if (*queue) {
        *queue = (*queue)->next;
    } else {
        return NULL;
    }
    return p;
}

int length_of_cmd(block *queue){
	int len = 0;
	block q = *queue;
	while (q != NULL){
		len++;
		if(q->c == '\r'){
			break;
		}
		q = q->next;
	}
	return len;
}

int serial_send_data(char* c){
//	int i;
//	for(i=0; *c != '\0'; i++){
//		TXarray[i] = (*c & (uint16_t)0x01FF);
//		c++;
//	}
	if(initialized == 0){
		initialize();
	}
	int i;
	for(i=0; *c != '\0'; i++){
		block ptr = dequeue(&freeQ);
		ptr->c = (*c & (uint16_t)0x01FF);
		enqueue(ptr, &TxQ);
		c++;
	}


	USART2->CR1 |= USART_FLAG_TXE;
	return (0);
}

int serial_get_data(){
	if(RxQ_ready == 0){
		return -1;
	}
	RxQ_ready = 0;
	block ptr;

	int len = length_of_cmd(&RxQ);
	char cmd_dat[len+1];
	char* cmd = &cmd_dat[0];
	char* msg;

//	ptr = dequeue(&RxQ);
//	cmd_dat[0] = ptr->c;
//	enqueue(ptr, &freeQ);
//
//	ptr = dequeue(&RxQ);
//	cmd_dat[1] = ptr->c;
//	enqueue(ptr, &freeQ);
//
//	ptr = dequeue(&RxQ);
//	cmd_dat[2] = ptr->c;
//	enqueue(ptr, &freeQ);
//
//	cmd_dat[3] = '\0';
//
//	serial_send_data(cmd);

	int i;
	for(i=0; i<len; i++){
		ptr = dequeue(&RxQ);
		cmd_dat[i] = ptr->c;
		enqueue(ptr, &freeQ);
	}
	cmd_dat[len] = '\0';

	//Echo
	serial_send_data(cmd);


	if(strcmp(cmd, on) == 0){
		GPIOA->ODR |= (1 << (5));
	}else if(strcmp(cmd, off) == 0){
		GPIOA->ODR &= ~(1 << (5));
	}else{
		msg = strcat(err, cmd_dat);
		serial_send_data(msg);
	}
	//else{
//		msg = "Hello";//strcat("Could not parse", cmd);
//		serial_send_data(msg);
//	}
	free(cmd_dat);
	return 0;
}

//struct test_struct* create_list(char data, struct test_struct* head, struct test_struct* curr)
//{
//    /* creating list with headnode as [%d]\n",data */
//    struct test_struct *ptr = (struct test_struct*)malloc(sizeof(struct test_struct));
//    if(NULL == ptr)
//    {
//        /* Node creation failed \n*/
//        return NULL;
//    }
//    ptr->data = data;
//    ptr->next = NULL;
//
//    head = curr = ptr;
//    return ptr;
//}
//
//struct test_struct* add_to_list(char data, bool add_to_end, struct test_struct* head, struct test_struct* curr)
//{
//    if(NULL == head)
//    {
//        return (create_list(data, head, curr));
//    }
//
//    struct test_struct *ptr = (struct test_struct*)malloc(sizeof(struct test_struct));
//    if(NULL == ptr)
//    {
//        /* Node creation failed */
//        return NULL;
//    }
//    ptr->data = data;
//    ptr->next = NULL;
//
//    if(add_to_end)
//    {
//        curr->next = ptr;
//        curr = ptr;
//    }
//    else
//    {
//        ptr->next = head;
//        head = ptr;
//    }
//    return ptr;
//}
//
//char get_head(struct test_struct* head)
//{
//    struct test_struct *ptr = head;
//    if(head == NULL){
//        return NULL;
//    }
//    head = head->next;
//    char data = ptr->data;
//    free(ptr);
//    return data;
//}





