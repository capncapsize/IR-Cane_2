/*
 * timer_conf.h
 *
 *  Created on: Feb 16, 2016
 *      Author: daveng-2
 */

#ifndef TIMER_CONF_H_
#define TIMER_CONF_H_

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"

#define   APB1_FREQ        84000000                           // Clock driving TIM1
#define   CNT_FREQ         2000                           // TIM3 counter clock (prescaled APB1)
#define   IT_PER_SEC       1                              // Interrupts per second
#define   TIM1_PULSE       ((CNT_FREQ) / (IT_PER_SEC))        // Output compare reg value
#define   TIM_PRESCALER    (((APB1_FREQ) / (CNT_FREQ))-1)

int init_TIM1(void);


#endif /* TIMER_CONF_H_ */
