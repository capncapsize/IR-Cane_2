

#include "controller.h"


//
int parseCmd(char* cmd){
//	if(*cmd == "on\r"){
//		writeLed(1);
//	}else if(*cmd == "off\r"){
//		writeLed(0);
//	}
//	return 1;
}
//
//
void writeLed(int i){
//	GPIOA->ODR ^= (i << (5));
}

