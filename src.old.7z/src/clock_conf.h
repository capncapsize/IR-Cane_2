/*
 * clock_conf.h
 *
 *  Created on: Feb 16, 2016
 *      Author: daveng-2
 */

#ifndef CLOCK_CONF_H_
#define CLOCK_CONF_H_

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"

int init_clock();

#endif /* CLOCK_CONF_H_ */
