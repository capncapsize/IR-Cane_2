/*
 * controller.h
 *
 *  Created on: Feb 18, 2016
 *      Author: daveng-2
 */

#ifndef CONTROLLER_H_
#define CONTROLLER_H_

int parseCmd(char* cmd);
void writeLed(int i);



#endif /* CONTROLLER_H_ */
